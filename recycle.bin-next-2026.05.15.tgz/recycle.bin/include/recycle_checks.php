<?php
/*
Copyright (C) 2015�2026 Dan Landon
Licensed under the Recycle Bin - Next Personal Use License v1.0
See LICENSE.md for full license terms.
*/

header('Content-Type: application/json');

/* Determine check & share. */
$check = '';
$share = '';

if (php_sapi_name() === 'cli') {
	$check = $argv[1] ?? '';
	$share = $argv[2] ?? '';
} else {
	$check = $_GET['check'] ?? '';
	$share = trim($_GET['share'] ?? '');
}

/* Initialize the rows. */
$rows	= [];

$recycle_file			= '/tmp/recycle.bin/combined_recycle_bins';
$expected_bins			= file_exists($recycle_file) ? file($recycle_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : [];

/* Settings for SMB file delete test. */
$last_test_file_file	= "/tmp/recycle.bin/recycle_bin_last_test_file";
$attempts_file			= "/tmp/recycle.bin/recycle_bin_attempts";
$active_share_file		= "/tmp/recycle.bin/recycle_bin_active_share";
$max_attempts			= 2;

/* Temporary function for translation. */
if (!function_exists('_')) {
	/* Temporary translation stub */
	function _($str) {
		return $str;
	}
}

/* Default response. */
$response = [
	'status'  => 2,
	'message' => _('Unknown check')
];

/* Ensure minimum runtime so spinner shows. */
$start_time	= microtime(true);

/* Minimum run time to give user the sense that it is actually wirking. */
$min_times = [2, 2.5, 3, 3.5, 4];
$min_time  = $min_times[array_rand($min_times)];

/* Default response */
$response = ['status' => 3, 'message' => "<tr class='none-found message-row'><td><em>Unknown check.</em></td></tr>"];

/*
	Return mount info (mountpoint + fstype) for the mount containing $path.
	Longest mountpoint prefix match against /proc/mounts.
*/
function get_mount_for_path($path) {
	$best		= ['mountpoint' => '', 'fstype' => ''];
	$bestLen	= -1;

	$lines = @file('/proc/mounts', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	if ($lines === false) {
		return $best;
	}

	foreach ($lines as $line) {
		$parts = preg_split('/\s+/', trim($line));
		if (!is_array($parts) || count($parts) < 3) {
			continue;
		}

		$mp = preg_replace_callback('/\\\\([0-7]{3})/', function($m) {
			return chr(octdec($m[1]));
		}, $parts[1]);

		$fs = $parts[2];

		if ($path === $mp || strncmp($path, $mp.'/', strlen($mp) + 1) === 0) {
			$len = strlen($mp);
			if ($len > $bestLen) {
				$bestLen = $len;
				$best = ['mountpoint' => $mp, 'fstype' => $fs];
			}
		}
	}

	return $best;
}

/* True if we should skip permission/ownership checks for this filesystem. */
function fstype_skip_checks($fstype) {
	static $skip = [
		'vfat'		=> true,
		'msdos'		=> true,
		'exfat'		=> true,
		'ntfs'		=> true,	/* ntfs-3g */
		'fuseblk'	=> true,	/* often reported for ntfs-3g */
	];

	return isset($skip[$fstype]);
}

/* Display-only normalization to match inotify log output. */
function normalize_display_path($path) {
	if ($path === '/boot') {
		$path = '/flash';
	} elseif (strncmp($path, '/boot/', 6) === 0) {
		$path = '/flash/'.substr($path, 6);
	}

	return $path;
}

/* Do the check. */
switch ($check) {
	case 'missing_bins':
		$type		= 'critical';
		$rows		= [];
		$missing	= [];
		$bad		= [];

		$expected_mode  = 0777;
		$expected_user  = 'nobody';
		$expected_group = 'users';

		foreach ($expected_bins as $path) {
			/* /boot: existence only, no permission/ownership checks. */
			if (strpos($path, '/boot/') === 0) {
				if (!is_dir($path)) {
					$missing[] = $path;
				}
				continue;
			}

			/* Everyone: existence check. */
			if (!is_dir($path)) {
				$missing[] = $path;
				continue;
			}

			/* UD non-POSIX (vfat/exfat/ntfs/etc): existence only (skip perms/ownership). */
			if (strpos($path, '/mnt/disks/') === 0) {
				$mount = get_mount_for_path($path);
				if (($mount['fstype']) && (fstype_skip_checks($mount['fstype']))) {
					continue;
				}
			}

			/* All other locations: perms/ownership checks. */
			$st = @stat($path);
			if ($st == false) {
				$bad[] = $path;
				continue;
			}

			$mode	= ($st['mode'] & 07777);
			$uid 	= $st['uid'];
			$gid	= $st['gid'];

			$pw		= function_exists('posix_getpwuid') ? @posix_getpwuid($uid) : false;
			$gr		= function_exists('posix_getgrgid') ? @posix_getgrgid($gid) : false;

			$user	= (is_array($pw) && isset($pw['name'])) ? $pw['name'] : '';
			$group	= (is_array($gr) && isset($gr['name'])) ? $gr['name'] : '';

			if (($mode != $expected_mode) || ($user != $expected_user) || ($group != $expected_group)) {
				$bad[] = $path;
			}
		}

		if ($missing) {
			usort($missing, 'strnatcasecmp');
			foreach ($missing as $path) {
				$rows[] = "<tr class='$type message-row'><td>".htmlspecialchars($path, ENT_QUOTES)." &mdash; <em>Recycle bin is missing.</em></td></tr>";
			}
		}

		if ($bad) {
			usort($bad, 'strnatcasecmp');
			foreach ($bad as $path) {
				$rows[] = "<tr class='$type message-row'><td>".htmlspecialchars($path, ENT_QUOTES)." &mdash; <em>Recycle bin has incorrect permissions or ownership.</em></td></tr>";
			}
		}

		if (!$missing && !$bad) {
			$str	= _('No missing recycle bins or incorrect recycle bin ownership or permissions detected');
			$rows[]	= "<tr class='none-found message-row'><td><em>{$str}.</em></td></tr>";
		}

		$response	= ['status' => 2, 'message' => implode('', $rows)];
		break;

	case 'extra_bins':
		$type		= 'informational';
		$rows		= [];
		$extra_bins	= [];

		/* Mount points to exclude. */
		$excluded_mounts = ['addons', 'remotes', 'rootshare', 'user0', 'RecycleBin', 'cache'];
		$valid_lookup = array_fill_keys($expected_bins, true);

		$mounts = array_filter(
			glob('/mnt/*', GLOB_ONLYDIR),
			fn($path) => !in_array(basename($path), $excluded_mounts, true)
		);

		foreach ($mounts as $mount) {
			/* Disk root check */
			if (preg_match('#^/mnt/disk\d+$#', $mount)) {
				$disk_bin = $mount.'/.Recycle.Bin';
				if (is_dir($disk_bin) && !isset($valid_lookup[$disk_bin])) {
					$extra_bins[] = $disk_bin;
				}
				continue;
			}

			/* Recursive scan under mount */
			$cmd	= sprintf('find %s -type d -name ".Recycle.Bin" 2>/dev/null', escapeshellarg($mount));
			$output	= shell_exec($cmd) ?: '';
			$bins	= array_filter(explode("\n", $output));

			foreach ($bins as $bin) {
				if (strpos($bin, '/.Recycle.Bin/.Recycle.Bin') != false) {
					continue;
				}
				if (! isset($valid_lookup[$bin])) {
					$extra_bins[] = $bin;
				}
			}
		}

		$extra_bins = array_values(array_unique($extra_bins));

		if ($extra_bins) {
			usort($extra_bins, 'strnatcasecmp');
			foreach ($extra_bins as $bin) {
				$rows[] = "<tr class='$type message-row'><td>".htmlspecialchars($bin, ENT_QUOTES)."</td></tr>";
			}
		} else {
			$str	= _('No extra recycle bins detected');
			$rows[]	= "<tr class='none-found message-row'><td><em>{$str}.</em></td></tr>";
		}

		$response	= ['status' => 2, 'message' => implode('', $rows)];
		break;

	case 'nested_bins':
		$type	= 'informational';
		$rows	= [];

		$expected_bins	= file_exists($recycle_file) ? file($recycle_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : [];

		$nested_bins = [];
		foreach ($expected_bins as $bin) {
			if (is_dir($bin)) {
				foreach (scandir($bin) as $item) {
					if ($item === '.' || $item === '..') continue;
					$full = $bin.'/'.$item;

					/* Check if it is a directory or symlink to a directory named .Recycle.Bin. */
					if ((is_dir($full) || is_link($full)) && basename($full) === '.Recycle.Bin') {
						$nested_bins[] = $full;
					}
				}
			}
		}

		if ($nested_bins) {
			usort($nested_bins, 'strnatcasecmp');
			foreach ($nested_bins as $bin) {
				$rows[] = "<tr class='$type message-row'><td>".htmlspecialchars($bin, ENT_QUOTES)."</td></tr>";
			}
		} else {
			$rows[]	= "<tr class='none-found message-row'><td><em>No nested recycle bins detected.</em></td></tr>";
		}

		$response	= ['status' => 2, 'message' => implode('', $rows)];
		break;

	case 'smb_test':
		$response = ['status' => 1, 'message' => "<tr class='critical message-row'><td><em>"._('Unknown error')."</em></td></tr>"];

		/* Share cannot be blank. */
		if ($share === '') {
			$response['status'] = 3;
			$response['message'] = "<tr class='critical message-row'><td><em>"._('No share path provided.')."</em></td></tr>";
			break;
		}

		/* Be sure the share is really a directory. */
		if (!is_dir($share)) {
			$response['status'] = 3;
			$response['message'] = "<tr class='critical message-row'><td><em>"._('Invalid share path.')."</em></td></tr>";
			break;
		}

		/* Normalize the share for displaying - boot becomes flash. */
		$normalized_share	= basename(normalize_display_path($share));

		/* Create a test file */
		$ts					= date('Ymd_His');
		$share				= rtrim($share, '/');
		$test_file			= "$share/recycle_bin_test_$ts.txt";

		/* Get the active share from the share file. */
		$active_share		= @file_get_contents($active_share_file) ?: '';
		if ($active_share !== $share) {
			@unlink($last_test_file_file);
			@unlink($attempts_file);

			/* Add text to the test file. */
			if (@file_put_contents($test_file, "Recycle Bin test\n") === false) {
				$response['status']		= 3;
				$response['message']	= "<tr class='critical message-row'><td><em>"._('Failed to create test file.')."</em></td></tr>";
			} else {
				file_put_contents($last_test_file_file, $test_file);
				file_put_contents($attempts_file, "0");
				file_put_contents($active_share_file, $share);

				$response['status']		= 0;
				$response['message']	= "<tr class='informational message-row'><td><em>".sprintf(_("Test file '%s' created on share '%s'. Delete it from the network share to continue."), basename($test_file), $normalized_share)."</em></td></tr>";
			}
			break;
		}

		/* Get the last text file. */
		$last_test_file = @file_get_contents($last_test_file_file);
		if (!$last_test_file) {
			$response['status']		= 3;
			$response['message']	= "<tr class='critical message-row'><td><em>"._('Cannot determine last test file.')."</em></td></tr>";
			break;
		}

		$attempts = (int)@file_get_contents($attempts_file);
		$attempts++;
		file_put_contents($attempts_file, $attempts);

		$log = @file_get_contents('/var/log/recycle.bin-deleted.log') ?: '';

		$expected_paths	= [$last_test_file];
		$normalized		= normalize_display_path($last_test_file);
		if ($normalized !== $last_test_file) {
			$expected_paths[] = $normalized;
		}

		$found = false;
		foreach ($expected_paths as $p) {
			if (strpos($log, "DELETE => {$p}") !== false) {
				$found = true;
				break;
			}
		}

		$mormalized_share	= basename(normalize_display_path($active_share));
		if ($found) {
			$response['status'] = 2;
			$response['message'] = "<tr class='none-found message-row'><td><em>".sprintf(_("Success: test file '%s' on share '%s' is now in the Recycle Bin and has been logged."), basename($last_test_file), $normalized_share)."</em></td></tr>";

			@unlink($last_test_file_file);
			@unlink($attempts_file);
			@unlink($active_share_file);
		} elseif ($attempts >= $max_attempts) {
			$response['status'] = 3;
			$response['message'] = "<tr class='critical message-row'><td><em>".sprintf(_("Verification failed for '%s' on share '%s'. Please run the test again."), basename($last_test_file), $normalized_share)."</em></td></tr>";

			@unlink($last_test_file_file);
			@unlink($attempts_file);
			@unlink($active_share_file);
		} else {
			$response['status'] = 1;
			$response['message'] = "<tr class='informational message-row'><td><em>".sprintf(_("Waiting for Recycle Bin confirmation for '%s' file deletion on share '%s'."), basename($last_test_file), $normalized_share)."</em></td></tr>";
		}
		break;
}

/* sleep remaining time if check was too fast. */
$elapsed	= microtime(true) - $start_time;
$remaining	= $min_time - $elapsed;
if ($remaining > 0) {
	usleep((int)($remaining * 1_000_000));
}

/* Finally, return JSON */
echo json_encode($response);
?>
