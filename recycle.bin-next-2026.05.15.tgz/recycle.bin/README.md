**Recycle Bin - Next**

This plugin adds a per-share `.Recycle.Bin` folder that holds files deleted over SMB until they are removed manually or automatically by an age-based cleanup schedule.

A `.Recycle.Bin` folder is created in each share the first time a file is deleted from that share. Deleted files can be restored by browsing to //Tower/Share/.Recycle.Bin.

User access to the `.Recycle.Bin` folder follows the same permissions as the parent share.

If the plugin is removed, existing `.Recycle.Bin` folders and their contents remain in the shares. If you do not want to keep deleted files, empty the recycle bins before removing the plugin.

**Note:** Recycle Bin only intercepts deletes performed over SMB on individual shares. Deletes from root shares, the Unraid web UI, the command line, Docker containers, or virtual machines bypass the recycle bin by design.

Originally developed and maintained by Dan Landon.

Project repository, documentation, and license information are available on GitHub.
