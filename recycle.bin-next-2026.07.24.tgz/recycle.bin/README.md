**Recycle Bin - Next**

This plugin adds a `.Recycle.Bin` folder to each Unraid share, where files deleted over SMB are kept until they are restored, removed manually, or deleted automatically by an age-based cleanup schedule.

Deleted and Removed Files logs provide searchable history with wildcard (`*`, `?`) and exclusion (`!`) filters.

Removing the plugin does not delete existing recycle bins or their contents.

**Note:** Only deletes performed over SMB on individual Unraid shares are recycled. Deletes from root shares, the Unraid web UI, the command line, Docker containers, or virtual machines bypass the recycle bin.

Originally developed and maintained by Dan Landon.

Project repository, documentation, and license information are available on GitHub.
