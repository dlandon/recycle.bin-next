<?php
/*
Copyright (C) 2015�2026 Dan Landon
Licensed under the Recycle Bin - Next Personal Use License v1.0
See LICENSE.md for full license terms.
*/

/* Define our plugin name. */
if (!defined('RECYCLE_PLUGIN')) {
	define('RECYCLE_PLUGIN', 'recycle.bin');
}

/* Define our plugin name. */
if (!defined('DOCROOT')) {
	define('DOCROOT', $_SERVER['DOCUMENT_ROOT'] ?: '/usr/local/emhttp');
}

$pidFile		= '/var/run/recycle.bin.pid';
$pidInotify		= '/var/run/recycle.bin.inotify.pid';
$pidRunning		= file_exists($pidFile);
$logPidRunning	= file_exists($pidInotify);
$pidStatus		= $pidRunning ? 'Running' : 'Stopped';
$pidColor 		= $pidStatus == 'Running' ? 'green' : 'orange';

/* Default today_only. */
$today_only = (($_COOKIE['recycle_activity_today_only'] ?? '0') === '1') ? 1 : 0;

/* Enable the filters? */
$filter_enabled = $pidRunning && $logPidRunning && ($recycle_bin_cfg['LOG'] == "yes");/* Function to filter the log lines based on filter settings. */

function filter_log(array $log_lines, bool $today_only, string $filter_text): array {
	if ($today_only) {
		$today_month = date('M');
		$today_day = date('j');

		$log_lines = array_filter($log_lines, static function ($line) use ($today_month, $today_day) {
			return preg_match("/^{$today_month}\s+0?{$today_day}\b/", $line);
		});
	}

	if ($filter_text !== '') {
		$terms = array_filter(array_map('trim', explode(',', $filter_text)));

		$use_mb = function_exists('mb_stripos');

		$log_lines = array_filter($log_lines, static function ($line) use ($terms, $use_mb) {
			foreach ($terms as $term) {
				$exclude = false;

				/* Leading ! means the term must NOT match */
				if (isset($term[0]) && $term[0] === '!') {
					$exclude = true;
					$term = substr($term, 1);
				}

				/* Ignore empty terms (e.g. "!,") */
				if ($term === '') {
					continue;
				}

				/* Determine whether the line matches the term */
				if (strpbrk($term, '*?') !== false) {
					$regex = '/.*' .
						str_replace(
							['\*', '\?'],
							['.*', '.'],
							preg_quote($term, '/')
						) .
						'.*/iu';

					$matched = (bool) preg_match($regex, $line);
				} else {
					$matched = $use_mb ? (mb_stripos($line, $term) !== false) : (stripos($line, $term) !== false);
				}

				/* Apply include/exclude logic */
				if ($exclude) {
					if ($matched) {
						return false;
					}
				} else {
					if (!$matched) {
						return false;
					}
				}
			}

			return true;
		});
	}

	return $log_lines;
}

$filter_help = implode("\n", [
	_("Enter one or more comma-separated search terms").".",
	_("All terms must match unless prefixed with '!'"),
	_("Use '!' to exclude matching entries."),
	_("Wildcards")." '*' "._("and")." '?' "._("are supported").".",
	_("Example").": 'Movies', 'Movies,*.mkv', '!*.tmp'"
]);
?>
